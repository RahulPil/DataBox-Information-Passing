### Program is meant to run on Visual Studio with openCV4.6
By Griffin Detracy, Camas Collins, and Rahul Pillalamarri

## bat Requirements
Requirements for create DataBox bat
  format
    start "" [exe] [true] [cell width (# on 1 row)] [resolution width] [bits Per Cell]
  example
    start "" ../x64/Debug/Project3CV.exe 1 24 1024 1

Requirements for find DataBox bat (dynamically determines the bits percell when reading)
  format
    start "" [exe] [false] [cell width (# on 1 row)] [fileName]
  example
    start "" ../x64/Debug/Project3CV.exe 0 24 test0.jpg


## existing bat and test images
Each run_CreateDB_* bat creates a databox based on the data in InputStringDBCreation.txt
Each runtest*_FindReadDB bat attempts to solve a use case
  test 0 is the base use case of the entire input image being the databox
  test 1 at an odd angle by the corner
  test 2 at an odd angle over the image
  test 3 being far away (relatively)
  test 4 being rotated at an odd angle
  test 5 being only 1 bit per cell
  test 6 being only 2 bits per cell


## extra files
InputStringDBCreation.txt contains the data to be used when creating a databox
output.txt is generated after finding a databox, it contains the data found
createdDataBox.jpg is generated after the program creates a new databox
